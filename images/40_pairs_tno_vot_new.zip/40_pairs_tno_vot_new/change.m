clear all
clc
% original images
test_path_ir = './ir/';
fileFolder_ir=fullfile(test_path_ir);
dirOutput_ir =dir(fullfile(fileFolder_ir,'*'));
num_ir = length(dirOutput_ir);

test_path_vis = replace(test_path_ir, '/ir/', '/vis/');
fileFolder_vis=fullfile(test_path_vis);
dirOutput_vis =dir(fullfile(fileFolder_vis,'*'));

for i=3:num_ir
    path_ir = [test_path_ir,dirOutput_ir(i).name]; % IR image
    path_vi = [test_path_vis,dirOutput_vis(i).name]; % VIS image
    
    img_ir = imread(path_ir);
    img_vi = imread(path_vi);
    
    if size(img_ir,3)>1
        img_ir = rgb2gray(img_ir);
        imwrite(img_ir, path_ir);
    end
    if size(img_vi,3)>1
        img_vi = rgb2gray(img_vi);
        imwrite(img_vi, path_vi);
    end
    
end